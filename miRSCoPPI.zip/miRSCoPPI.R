#################################################################################### 
## miRSCoPPI: Inferring miRNA sponge co-regulation of PPIs in human breast cancer
## March 6th, 2017, written by Junpeng Zhang
####################################################################################

## Get data from file ##
Read<-function(dataset){
   data<-read.csv(dataset, header=TRUE, sep=",")
   return(data)
}

## Get data header from dataset ##
readHeader<-function(dataset){
  data<-read.csv(dataset, header=F)
  header<-character()
  for (i in 1:ncol(data)){
  header[i]=toString(data[1,i])
  }
  return(header)
}

## Calculate correlations of miRNA-target (miRNA-mRNA and miRNA-lncRNA) interactions ##
Pearson<-function(datacsv, cause, effect){
  data=Read(datacsv)
  data=scale(data) #standardise the data
  header<-readHeader(datacsv)
  num_miRNA<-length(cause)
  miR<-header[1:num_miRNA]
  tar<-header[-(1:num_miRNA)]

  miRNA=data[,cause]
  target=data[,effect]
  corMat=cor(target, miRNA, method="pearson") # miRNAs in columns, targets (lncRNAs and mRNAs) in rows

return(corMat)
}

## Constructing miRNA-target binding matrix using putative miRNA-target interactions ##
Bindingmatrix<-function(miRNA,target,file){
  
  #the column name of file should be tagged as "mir" and "gene"
  data<-Read(file)
  mir=as.character(data$mir)
  #   mir<-paste("hsa-",sep="",mir);mir<-sub('r','R',mir)
  gene=as.character(data$gene)
  #   symbol<-geneSymbol(gene)   

  rep<-replicate(length(miRNA),mir)
  edge=matrix(F,length(miRNA)+length(target),length(miRNA)+length(target))
  for (i in 1:length(mir)){
    
    if (length(which(rep[i,]==miRNA)>0)){
      match1<-which(rep[i,]==miRNA,arr.ind=T)
      #gene: gene[i] #mirna: miRNA[match]
      rep2<-replicate(length(target),gene[i])
      match2<-which(rep2==target,arr.ind=T)
      edge[match1,match2+length(miRNA)]=T
    }
  }
  return(edge)
}


## Extract miRNA-target interactions by combining expression data and putative miRNA-target interactions ##
QueryTargetbinding<-function(datacsv,miRbinding){
  ExpDataNames=readHeader(datacsv)
  miRtarget<-read.csv(miRbinding, header=FALSE, sep=",")
  miRtarget=as.matrix(miRtarget)
  
  miRtargetCandidate=miRtarget[intersect(which(miRtarget[,1] %in% ExpDataNames),which(miRtarget[,2] %in% ExpDataNames)),]   
  return(miRtargetCandidate)
}

## Generate miRNA-target correlation matrix by combining expression data and putative miRNA-target interactions ##
Corscore<-function(datacsv, cause, effect, ExpDataNames, targetbinding=NA){
        
  CE=Pearson(datacsv, cause, effect)
  ACE=abs(CE)

  if(is.na(targetbinding)==FALSE){
  #query knowledge matrix from file
  num_miRNA=length(cause)
  miR=ExpDataNames[1:num_miRNA]
  tar=ExpDataNames[-(1:num_miRNA)]

  edgeTargetScan=Bindingmatrix(miR,tar,targetbinding)
  edgeTargetScan=edgeTargetScan+t(edgeTargetScan)
  binaryedge=edgeTargetScan!=0
  edge=binaryedge[effect,cause]

  ACE=ACE*edge
  CE=CE*edge
}

return(list(ACE,CE))
}

## Identifying candidate miRNA sponge interaction pairs ##
ceRceR<-function(miRtargetCandidate, ACE, CE, ExpData, ExpDataNames, nummiR){
        
        miRtargetCandidate=miRtargetCandidate[sort.list(miRtargetCandidate[,2]),]
        miRtargetCandidate=as.matrix(miRtargetCandidate)
        m1=nrow(miRtargetCandidate)
        n1=ncol(miRtargetCandidate)
                       
        miR=miRtargetCandidate[,1]
        tar=miRtargetCandidate[,2]        
        
        miRSym=table(miR)
        targetSym=table(tar)        

        m2=dim(targetSym)
        K=as.matrix(as.numeric(targetSym))
        target=as.matrix(rownames(targetSym))
        
        ## Initialize variables
        ceRInt=matrix(NA,m2*(m2-1)/2,2)
        C=matrix(NA,m2*(m2-1)/2,5)
      
        for (i in 1:(m2-1)){
              for (j in (i+1):m2){

                 kk_1=(sum(K[1:i-1])+1):sum(K[1:i])
                 Interin1=miRtargetCandidate[kk_1,1]
             
                 kk_2=(sum(K[1:j-1])+1):sum(K[1:j])
                 Interin2=miRtargetCandidate[kk_2,1]
                 
                 M1=length(Interin1)
                 M2=length(Interin2)
                 M3=length(intersect(Interin1,Interin2))
                 M4=dim(miRSym)
                 M5=1-phyper(M3-1,M2,M4-M2,M1)
                
                 if (M3>2 & M5<0.01){
                        
                        ceRInt[(i-1)*m2+j-sum(1:i),1]=target[i]
                        ceRInt[(i-1)*m2+j-sum(1:i),2]=target[j]

                        tarExpIdx1= which(ExpDataNames==target[i,1])
                        tarExpIdx2= which(ExpDataNames==target[j,1])
                        
                        tarIdx1= tarExpIdx1-nummiR
                        tarIdx2= tarExpIdx2-nummiR                                       

                        M6=cor.test(ExpData[,tarExpIdx1],ExpData[,tarExpIdx2])$estimate
                        M7=cor.test(ExpData[,tarExpIdx1],ExpData[,tarExpIdx2])$p.value
                        
                        ## Collarboration score for similarity measure
                        M8=(ACE[tarIdx1,]%*%ACE[tarIdx2,])/( sqrt(sum(ACE[tarIdx1,intersect(which(ACE[tarIdx1,]!=0), which(ACE[tarIdx2,]!=0))])*sum(ACE[tarIdx2,intersect(which(ACE[tarIdx1,]!=0), which(ACE[tarIdx2,]!=0))])) )
                        
                        ## Cosine score for similarity measure
                        M9=(CE[tarIdx1,]%*%CE[tarIdx2,])/( sqrt(sum(CE[tarIdx1,intersect(which(CE[tarIdx1,]!=0), which(CE[tarIdx2,]!=0))]^2)*sum(CE[tarIdx2,intersect(which(CE[tarIdx1,]!=0), which(CE[tarIdx2,]!=0))]^2)) )
                     
                        C[(i-1)*m2+j-sum(1:i),1]=M6
                        C[(i-1)*m2+j-sum(1:i),2]=M7
                        C[(i-1)*m2+j-sum(1:i),3]=M8
                        C[(i-1)*m2+j-sum(1:i),4]=M9
                        C[(i-1)*m2+j-sum(1:i),5]=M3    
                     
                 }
                
             }
        }

ceRInt=ceRInt[which((C[,1]>0 & C[,2]<0.01 & 0.5*(C[,3]+C[,4])>0.5)=='TRUE'),]
C=C[which((C[,1]>0 & C[,2]<0.01 & 0.5*(C[,3]+C[,4])>0.5)=='TRUE'),]
PCceRInt=cbind(ceRInt,C)
return(PCceRInt)
}

## Function of SVM 10-fold classification
SVMClassifier<-function(yourData,tumor,normal){
library(e1071)
library(ROCR)

yourData1<-yourData[tumor,]
yourData2<-yourData[normal,]
#Randomly shuffle the data
set.seed(1234)
yourData1<-yourData1[sample(nrow(yourData1)),]
yourData2<-yourData2[sample(nrow(yourData2)),]
yourData=rbind(yourData1,yourData2)

#Create 10 equally size folds
folds1 <- cut(seq(1,nrow(yourData1)),breaks=10,labels=FALSE)
folds2 <- cut(seq(1,nrow(yourData2)),breaks=10,labels=FALSE)

#Perform 10 fold cross validation
testIndexes=lapply(1:10, function(i) c(which(folds1==i,arr.ind=TRUE), which(folds2==i,arr.ind=TRUE)+length(tumor)))
testData=lapply(1:10, function(i) yourData[testIndexes[[i]],])
trainData=lapply(1:10, function(i) yourData[-testIndexes[[i]],])

#learning from training
svmmodel<-lapply(1:10, function(i) svm(Class~., data=trainData[[i]], method="C-classification", kernel="radial",probability=TRUE))

#predicting the test data
svmmodel.predict<-lapply(1:10, function(i) predict(svmmodel[[i]],testData[[i]],decision.values=TRUE))
svmmodel.probs<-lapply(1:10, function(i) attr(svmmodel.predict[[i]],"decision.values"))
svmmodel.class<-lapply(1:10, function(i) svmmodel.predict[[i]][1:dim(testData[[i]])[1]])
svmmodel.labels<-lapply(1:10, function(i) testData[[i]]$Class)

#analyzing result
svmmodel.table<-lapply(1:10, function(i) table(svmmodel.predict[[i]],testData[[i]]$Class))
svmmodel.accuracy<-lapply(1:10, function(i) sum(diag(svmmodel.table[[i]]))/sum(svmmodel.table[[i]]))
svmACC=mean(unlist(svmmodel.accuracy))

#ROC analysis for test data
svmmodel.prediction<-lapply(1:10, function(i) prediction(svmmodel.probs[[i]],svmmodel.labels[[i]]))
svmmodel.performance<-lapply(1:10, function(i) performance(svmmodel.prediction[[i]],"tpr","fpr"))
svmmodel.auc<-lapply(1:10, function(i) performance(svmmodel.prediction[[i]],"auc")@y.values[[1]])
svmAUC=mean(unlist(svmmodel.auc))
if(svmAUC<0.5){svmAUC=1-svmAUC}

return(list(svmAUC,svmACC))
}
